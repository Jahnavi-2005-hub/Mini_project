CREATE TABLE `budgetAlerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`platform` varchar(50) NOT NULL,
	`budgetPrice` int NOT NULL,
	`currentPrice` int NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	`notificationSent` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `budgetAlerts_id` PRIMARY KEY(`id`)
);
