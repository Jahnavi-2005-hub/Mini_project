import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  productUrl: text("productUrl"),
  category: varchar("category", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

export const priceComparisons = mysqlTable("priceComparisons", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productId: int("productId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  amazonPrice: int("amazonPrice"), // Store in paise (multiply by 100)
  flipkartPrice: int("flipkartPrice"), // Store in paise (multiply by 100)
  amazonUrl: text("amazonUrl"),
  flipkartUrl: text("flipkartUrl"),
  cheaperPlatform: varchar("cheaperPlatform", { length: 50 }), // 'amazon' or 'flipkart'
  savingsAmount: int("savingsAmount"), // In paise
  comparisonDate: timestamp("comparisonDate").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PriceComparison = typeof priceComparisons.$inferSelect;
export type InsertPriceComparison = typeof priceComparisons.$inferInsert;

export const userSavings = mysqlTable("userSavings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  totalSavings: int("totalSavings").default(0).notNull(), // In paise
  comparisonsCount: int("comparisonsCount").default(0).notNull(),
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow().notNull(),
});

export type UserSavings = typeof userSavings.$inferSelect;
export type InsertUserSavings = typeof userSavings.$inferInsert;

export const pricePredictions = mysqlTable("pricePredictions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  platform: varchar("platform", { length: 50 }).notNull(), // 'amazon' or 'flipkart'
  currentPrice: int("currentPrice").notNull(), // In paise
  predictedPrice: int("predictedPrice").notNull(), // In paise
  predictedDate: timestamp("predictedDate").notNull(),
  trend: varchar("trend", { length: 50 }).notNull(), // 'up', 'down', 'stable'
  confidence: int("confidence").notNull(), // 0-100
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PricePrediction = typeof pricePredictions.$inferSelect;
export type InsertPricePrediction = typeof pricePredictions.$inferInsert;

export const priceHistory = mysqlTable("priceHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  platform: varchar("platform", { length: 50 }).notNull(), // 'amazon' or 'flipkart'
  price: int("price").notNull(), // In paise
  productId: varchar("productId", { length: 255 }), // External product ID from API
  fetchedAt: timestamp("fetchedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PriceHistory = typeof priceHistory.$inferSelect;
export type InsertPriceHistory = typeof priceHistory.$inferInsert;

export const productCache = mysqlTable("productCache", {
  id: int("id").autoincrement().primaryKey(),
  productName: varchar("productName", { length: 255 }).notNull().unique(),
  amazonProductId: varchar("amazonProductId", { length: 255 }),
  flipkartProductId: varchar("flipkartProductId", { length: 255 }),
  lastFetched: timestamp("lastFetched").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProductCache = typeof productCache.$inferSelect;
export type InsertProductCache = typeof productCache.$inferInsert;
export const budgetAlerts = mysqlTable("budgetAlerts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  platform: varchar("platform", { length: 50 }).notNull(),
  budgetPrice: int("budgetPrice").notNull(),
  currentPrice: int("currentPrice").notNull(),
  isActive: int("isActive").default(1).notNull(),
  notificationSent: int("notificationSent").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BudgetAlert = typeof budgetAlerts.$inferSelect;
export type InsertBudgetAlert = typeof budgetAlerts.$inferInsert;
