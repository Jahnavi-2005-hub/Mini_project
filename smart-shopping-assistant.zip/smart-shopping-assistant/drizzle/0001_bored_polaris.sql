CREATE TABLE `priceComparisons` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`amazonPrice` int,
	`flipkartPrice` int,
	`amazonUrl` text,
	`flipkartUrl` text,
	`cheaperPlatform` varchar(50),
	`savingsAmount` int,
	`comparisonDate` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `priceComparisons_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pricePredictions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`platform` varchar(50) NOT NULL,
	`currentPrice` int NOT NULL,
	`predictedPrice` int NOT NULL,
	`predictedDate` timestamp NOT NULL,
	`trend` varchar(50) NOT NULL,
	`confidence` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pricePredictions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`productUrl` text,
	`category` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userSavings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`totalSavings` int NOT NULL DEFAULT 0,
	`comparisonsCount` int NOT NULL DEFAULT 0,
	`lastUpdated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userSavings_id` PRIMARY KEY(`id`)
);
