CREATE TABLE `priceHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`platform` varchar(50) NOT NULL,
	`price` int NOT NULL,
	`productId` varchar(255),
	`fetchedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `priceHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `productCache` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productName` varchar(255) NOT NULL,
	`amazonProductId` varchar(255),
	`flipkartProductId` varchar(255),
	`lastFetched` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `productCache_id` PRIMARY KEY(`id`),
	CONSTRAINT `productCache_productName_unique` UNIQUE(`productName`)
);
