import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { 
  getUserComparisons, 
  getUserPredictions, 
  createComparison, 
  createPrediction, 
  getOrCreateUserSavings,
  addPriceHistory,
  getPriceHistory,
  getProductCache,
  upsertProductCache,
  createBudgetAlert,
  getUserBudgetAlerts,
  updateBudgetAlert,
  deleteBudgetAlert,
} from "./db";
import { compareProductPrices, getSupportedProducts } from "./services/priceApi";
import { predictPrice, PricePoint } from "./services/prediction";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  comparison: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserComparisons(ctx.user.id, 20);
    }),
    
    search: protectedProcedure
      .input(z.object({
        productName: z.string().min(1),
      }))
      .query(async ({ ctx, input }) => {
        try {
          const result = await compareProductPrices(input.productName);
          
          if (result.amazon) {
            await addPriceHistory({
              userId: ctx.user.id,
              productName: input.productName,
              platform: "amazon",
              price: Math.round(result.amazon.price * 100),
              productId: result.amazon.productId,
            });
          }
          
          if (result.flipkart) {
            await addPriceHistory({
              userId: ctx.user.id,
              productName: input.productName,
              platform: "flipkart",
              price: Math.round(result.flipkart.price * 100),
              productId: result.flipkart.productId,
            });
          }
          
          if (result.amazon || result.flipkart) {
            await upsertProductCache({
              productName: input.productName,
              amazonProductId: result.amazon?.productId,
              flipkartProductId: result.flipkart?.productId,
            });
          }
          
          return {
            productName: result.productName,
            amazon: result.amazon ? {
              ...result.amazon,
              price: result.amazon.price,
            } : null,
            flipkart: result.flipkart ? {
              ...result.flipkart,
              price: result.flipkart.price,
            } : null,
            cheaper: result.cheaper,
            savings: result.savings,
          };
        } catch (error) {
          console.error("Error searching product:", error);
          throw new Error("Failed to fetch product prices");
        }
      }),
    
    create: protectedProcedure
      .input(z.object({
        productName: z.string(),
        amazonPrice: z.number().optional(),
        flipkartPrice: z.number().optional(),
        amazonUrl: z.string().optional(),
        flipkartUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const amazonPrice = input.amazonPrice ? Math.round(input.amazonPrice * 100) : null;
        const flipkartPrice = input.flipkartPrice ? Math.round(input.flipkartPrice * 100) : null;
        
        let cheaperPlatform = null;
        let savingsAmount = 0;
        
        if (amazonPrice && flipkartPrice) {
          if (amazonPrice < flipkartPrice) {
            cheaperPlatform = 'amazon';
            savingsAmount = flipkartPrice - amazonPrice;
          } else {
            cheaperPlatform = 'flipkart';
            savingsAmount = amazonPrice - flipkartPrice;
          }
        }
        
        return createComparison({
          userId: ctx.user.id,
          productId: 0,
          productName: input.productName,
          amazonPrice,
          flipkartPrice,
          amazonUrl: input.amazonUrl,
          flipkartUrl: input.flipkartUrl,
          cheaperPlatform,
          savingsAmount,
        });
      }),
  }),
  
  dashboard: router({
    getSavings: protectedProcedure.query(async ({ ctx }) => {
      const savings = await getOrCreateUserSavings(ctx.user.id);
      return {
        totalSavings: savings?.totalSavings ? savings.totalSavings / 100 : 0,
        comparisonsCount: savings?.comparisonsCount || 0,
      };
    }),
    getRecentComparisons: protectedProcedure.query(async ({ ctx }) => {
      const comparisons = await getUserComparisons(ctx.user.id, 5);
      return comparisons.map(c => ({
        ...c,
        amazonPrice: c.amazonPrice ? c.amazonPrice / 100 : null,
        flipkartPrice: c.flipkartPrice ? c.flipkartPrice / 100 : null,
        savingsAmount: c.savingsAmount ? c.savingsAmount / 100 : 0,
      }));
    }),
  }),
  
  prediction: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const predictions = await getUserPredictions(ctx.user.id, 20);
      return predictions.map(p => ({
        ...p,
        currentPrice: p.currentPrice / 100,
        predictedPrice: p.predictedPrice / 100,
      }));
    }),
    
    generate: protectedProcedure
      .input(z.object({
        productName: z.string().min(1),
        platform: z.enum(['amazon', 'flipkart']),
        daysAhead: z.number().default(7),
      }))
      .query(async ({ ctx, input }) => {
        try {
          const history = await getPriceHistory(input.productName, input.platform, 30);
          
          if (history.length === 0) {
            return {
              error: "Not enough price history data. Please compare this product first.",
              prediction: null,
            };
          }
          
          const pricePoints: PricePoint[] = history.map(h => ({
            price: h.price / 100,
            date: h.fetchedAt,
          }));
          
          const prediction = predictPrice(pricePoints, input.daysAhead);
          
          return {
            error: null,
            prediction: {
              productName: input.productName,
              platform: input.platform,
              currentPrice: prediction.currentPrice,
              predictedPrice: prediction.predictedPrice,
              trend: prediction.trend,
              confidence: prediction.confidence,
              reasoning: prediction.reasoning,
              daysAhead: input.daysAhead,
            },
          };
        } catch (error) {
          console.error("Error generating prediction:", error);
          return {
            error: "Failed to generate prediction",
            prediction: null,
          };
        }
      }),
    
    create: protectedProcedure
      .input(z.object({
        productName: z.string(),
        platform: z.enum(['amazon', 'flipkart']),
        currentPrice: z.number(),
        predictedPrice: z.number(),
        predictedDate: z.date(),
        trend: z.enum(['up', 'down', 'stable']),
        confidence: z.number().min(0).max(100),
      }))
      .mutation(async ({ ctx, input }) => {
        return createPrediction({
          userId: ctx.user.id,
          productName: input.productName,
          platform: input.platform,
          currentPrice: Math.round(input.currentPrice * 100),
          predictedPrice: Math.round(input.predictedPrice * 100),
          predictedDate: input.predictedDate,
          trend: input.trend,
          confidence: input.confidence,
        });
      }),
  }),

  budgetAlert: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const alerts = await getUserBudgetAlerts(ctx.user.id);
      return alerts.map(a => ({
        ...a,
        budgetPrice: a.budgetPrice / 100,
        currentPrice: a.currentPrice / 100,
      }));
    }),

    create: protectedProcedure
      .input(z.object({
        productName: z.string().min(1),
        platform: z.enum(['amazon', 'flipkart']),
        budgetPrice: z.number().min(0),
        currentPrice: z.number().min(0),
      }))
      .mutation(async ({ ctx, input }) => {
        return createBudgetAlert({
          userId: ctx.user.id,
          productName: input.productName,
          platform: input.platform,
          budgetPrice: Math.round(input.budgetPrice * 100),
          currentPrice: Math.round(input.currentPrice * 100),
          isActive: 1,
          notificationSent: 0,
        });
      }),

    delete: protectedProcedure
      .input(z.object({ alertId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return deleteBudgetAlert(input.alertId);
      }),
  }),
  
  products: router({
    getSupportedProducts: publicProcedure.query(() => {
      return getSupportedProducts();
    }),
  }),
});

export type AppRouter = typeof appRouter;
