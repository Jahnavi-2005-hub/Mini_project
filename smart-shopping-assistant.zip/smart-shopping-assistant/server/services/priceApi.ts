import { ENV } from "../_core/env";
import { getProduct, generateProductPrice, searchProducts, getAllProductNames } from "./productDatabase";

export interface PriceData {
  productId: string;
  productName: string;
  price: number;
  currency: string;
  url?: string;
  rating?: number;
  availability?: boolean;
  image?: string;
}

export interface ComparisonResult {
  productName: string;
  amazon?: PriceData;
  flipkart?: PriceData;
  cheaper?: "amazon" | "flipkart";
  savings?: number;
}

/**
 * Find best matching product from database
 * Uses fuzzy matching to handle partial product names and brand names
 */
function findMatchingProduct(productName: string) {
  const normalizedInput = productName.toLowerCase().trim();
  
  // First try exact match
  let product = getProduct(productName);
  if (product) return product;
  
  // Try search with the full query
  const searchResults = searchProducts(productName, 100);
  if (searchResults.length > 0) return searchResults[0];
  
  // Try to find by brand or partial match
  const allProducts = getAllProductNames();
  for (const productFullName of allProducts) {
    if (productFullName.toLowerCase().includes(normalizedInput)) {
      const found = getProduct(productFullName);
      if (found) return found;
    }
  }
  
  // Try reverse match - check if input is part of any product name
  for (const productFullName of allProducts) {
    const productLower = productFullName.toLowerCase();
    const words = normalizedInput.split(/\s+/);
    let matchCount = 0;
    
    for (const word of words) {
      if (productLower.includes(word)) {
        matchCount++;
      }
    }
    
    if (matchCount > 0 && matchCount >= words.length * 0.5) {
      const found = getProduct(productFullName);
      if (found) return found;
    }
  }
  
  return null;
}

/**
 * Fetch price from Flipkart using RapidAPI
 * Endpoint: real-time-flipkart-data2.p.rapidapi.com
 */
async function fetchFlipkartPrice(productName: string): Promise<PriceData | null> {
  try {
    const rapidApiKey = ENV.rapidApiKey;
    const rapidApiHost = ENV.flipkartApiHost;

    if (!rapidApiKey) {
      console.warn("RAPIDAPI_KEY not configured, using local database");
      return getFlipkartMockData(productName);
    }

    // Try to search for product on Flipkart
    try {
      const searchUrl = `https://${rapidApiHost}/product-search?q=${encodeURIComponent(productName)}&pincode=400001`;
      console.log("Flipkart search URL:", searchUrl);

      const searchResponse = await fetch(searchUrl, {
        method: "GET",
        headers: {
          "x-rapidapi-host": rapidApiHost,
          "x-rapidapi-key": rapidApiKey,
        },
      });

      if (!searchResponse.ok) {
        console.error("Flipkart API search error:", searchResponse.status, searchResponse.statusText);
        return getFlipkartMockData(productName);
      }

      const searchData = await searchResponse.json();
      console.log("Flipkart search response:", searchData);

      // Extract first product from search results
      if (searchData && Array.isArray(searchData)) {
        const product = searchData[0];
        if (product) {
          return {
            productId: product.id || product.productId || "",
            productName: product.title || product.name || productName,
            price: parseFloat(product.price || product.discountedPrice || product.originalPrice || 0),
            currency: "INR",
            url: product.productUrl || product.url || "",
            rating: parseFloat(product.rating || 0),
            availability: product.inStock !== false && product.availability !== "Out of Stock",
            image: product.image || product.imageUrl || "",
          };
        }
      } else if (searchData && searchData.data && Array.isArray(searchData.data)) {
        const product = searchData.data[0];
        if (product) {
          return {
            productId: product.id || product.productId || "",
            productName: product.title || product.name || productName,
            price: parseFloat(product.price || product.discountedPrice || product.originalPrice || 0),
            currency: "INR",
            url: product.productUrl || product.url || "",
            rating: parseFloat(product.rating || 0),
            availability: product.inStock !== false && product.availability !== "Out of Stock",
            image: product.image || product.imageUrl || "",
          };
        }
      }

      return getFlipkartMockData(productName);
    } catch (apiError) {
      console.error("Flipkart API error:", apiError);
      return getFlipkartMockData(productName);
    }
  } catch (error) {
    console.error("Error fetching Flipkart price:", error);
    return getFlipkartMockData(productName);
  }
}

/**
 * Fetch price from Amazon using RapidAPI
 * Endpoint: scout-amazon-data.p.rapidapi.com
 */
async function fetchAmazonPrice(productName: string): Promise<PriceData | null> {
  try {
    const rapidApiKey = ENV.rapidApiKey;
    const rapidApiHost = ENV.amazonApiHost;

    if (!rapidApiKey) {
      console.warn("RAPIDAPI_KEY not configured, using local database");
      return getAmazonMockData(productName);
    }

    // Try to search for product on Amazon
    try {
      const searchUrl = `https://${rapidApiHost}/search?keyword=${encodeURIComponent(productName)}&region=IN`;
      console.log("Amazon search URL:", searchUrl);

      const searchResponse = await fetch(searchUrl, {
        method: "GET",
        headers: {
          "x-rapidapi-host": rapidApiHost,
          "x-rapidapi-key": rapidApiKey,
        },
      });

      if (!searchResponse.ok) {
        console.error("Amazon API search error:", searchResponse.status, searchResponse.statusText);
        return getAmazonMockData(productName);
      }

      const searchData = await searchResponse.json();
      console.log("Amazon search response:", searchData);

      // Extract first product from search results
      if (searchData && Array.isArray(searchData)) {
        const product = searchData[0];
        if (product) {
          return {
            productId: product.asin || product.id || "",
            productName: product.title || product.name || productName,
            price: parseFloat(product.price || product.current_price || product.discounted_price || 0),
            currency: "INR",
            url: product.productUrl || product.url || product.link || "",
            rating: parseFloat(product.rating || product.stars || 0),
            availability: product.availability !== "Out of Stock" && product.inStock !== false,
            image: product.image || product.imageUrl || product.image_url || "",
          };
        }
      } else if (searchData && searchData.data && Array.isArray(searchData.data)) {
        const product = searchData.data[0];
        if (product) {
          return {
            productId: product.asin || product.id || "",
            productName: product.title || product.name || productName,
            price: parseFloat(product.price || product.current_price || product.discounted_price || 0),
            currency: "INR",
            url: product.productUrl || product.url || product.link || "",
            rating: parseFloat(product.rating || product.stars || 0),
            availability: product.availability !== "Out of Stock" && product.inStock !== false,
            image: product.image || product.imageUrl || product.image_url || "",
          };
        }
      }

      return getAmazonMockData(productName);
    } catch (apiError) {
      console.error("Amazon API error:", apiError);
      return getAmazonMockData(productName);
    }
  } catch (error) {
    console.error("Error fetching Amazon price:", error);
    return getAmazonMockData(productName);
  }
}

/**
 * Mock data for fallback when API is not available
 * Uses intelligent product matching from the database
 */
function getAmazonMockData(productName: string): PriceData | null {
  const product = findMatchingProduct(productName);
  
  if (!product) {
    console.warn(`Product not found in database: ${productName}`);
    return null;
  }

  const price = generateProductPrice(product);
  const rating = 3.5 + Math.random() * 1.5; // 3.5-5.0
  const productSlug = product.name.replace(/\s+/g, "-").toLowerCase();
  const asin = `B0${Math.random().toString(36).substring(2, 10).toUpperCase()}`;

  return {
    productId: asin,
    productName: product.name,
    price: price,
    currency: "INR",
    url: `https://www.amazon.in/s?k=${encodeURIComponent(product.name)}`,
    rating: rating,
    availability: Math.random() > 0.1, // 90% availability
  };
}

function getFlipkartMockData(productName: string): PriceData | null {
  const product = findMatchingProduct(productName);
  
  if (!product) {
    console.warn(`Product not found in database: ${productName}`);
    return null;
  }

  const price = generateProductPrice(product);
  const rating = 3.5 + Math.random() * 1.5; // 3.5-5.0
  const productSlug = product.name.replace(/\s+/g, "-").toLowerCase();

  return {
    productId: `FK-${product.name.replace(/\s+/g, "-").toUpperCase()}`,
    productName: product.name,
    price: price,
    currency: "INR",
    url: `https://www.flipkart.com/search?q=${encodeURIComponent(product.name)}`,
    rating: rating,
    availability: Math.random() > 0.1, // 90% availability
  };
}

/**
 * Compare prices between Amazon and Flipkart
 */
export async function compareProductPrices(
  productName: string
): Promise<ComparisonResult> {
  // First check if product exists in database
  const product = findMatchingProduct(productName);
  
  if (!product) {
    return {
      productName,
      amazon: undefined,
      flipkart: undefined,
    };
  }

  const [amazonData, flipkartData] = await Promise.all([
    fetchAmazonPrice(productName),
    fetchFlipkartPrice(productName),
  ]);

  let cheaper: "amazon" | "flipkart" | undefined;
  let savings = 0;

  if (amazonData && flipkartData) {
    if (amazonData.price < flipkartData.price) {
      cheaper = "amazon";
      savings = flipkartData.price - amazonData.price;
    } else {
      cheaper = "flipkart";
      savings = amazonData.price - flipkartData.price;
    }
  }

  return {
    productName: product.name,
    amazon: amazonData || undefined,
    flipkart: flipkartData || undefined,
    cheaper,
    savings,
  };
}

/**
 * Get list of supported products for autocomplete
 * Returns all 200+ products from the database
 */
export function getSupportedProducts(): string[] {
  return getAllProductNames();
}

/**
 * Search products by query
 */
export function searchProductsByQuery(query: string): string[] {
  const results = searchProducts(query, 100);
  return results.map((p) => p.name);
}
