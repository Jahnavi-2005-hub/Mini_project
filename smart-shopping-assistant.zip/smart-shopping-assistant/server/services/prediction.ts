/**
 * Trend-based price prediction algorithm
 * Uses historical price data to predict future prices
 */

export interface PricePoint {
  price: number;
  date: Date;
}

export interface PredictionResult {
  currentPrice: number;
  predictedPrice: number;
  trend: "up" | "down" | "stable";
  confidence: number;
  reasoning: string;
}

/**
 * Calculate simple moving average
 */
function calculateMovingAverage(prices: number[], period: number): number {
  if (prices.length < period) {
    return prices.reduce((a, b) => a + b, 0) / prices.length;
  }
  const recentPrices = prices.slice(-period);
  return recentPrices.reduce((a, b) => a + b, 0) / period;
}

/**
 * Calculate price trend from historical data
 */
function calculateTrend(
  prices: number[]
): { trend: "up" | "down" | "stable"; strength: number } {
  if (prices.length < 2) {
    return { trend: "stable", strength: 0 };
  }

  const firstHalf = prices.slice(0, Math.floor(prices.length / 2));
  const secondHalf = prices.slice(Math.floor(prices.length / 2));

  const firstAvg = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length;
  const secondAvg = secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length;

  const percentChange = ((secondAvg - firstAvg) / firstAvg) * 100;

  if (percentChange > 2) {
    return { trend: "up", strength: Math.min(Math.abs(percentChange), 100) };
  } else if (percentChange < -2) {
    return { trend: "down", strength: Math.min(Math.abs(percentChange), 100) };
  } else {
    return { trend: "stable", strength: 0 };
  }
}

/**
 * Calculate volatility (standard deviation)
 */
function calculateVolatility(prices: number[]): number {
  if (prices.length < 2) return 0;

  const mean = prices.reduce((a, b) => a + b, 0) / prices.length;
  const squaredDiffs = prices.map((p) => Math.pow(p - mean, 2));
  const variance = squaredDiffs.reduce((a, b) => a + b, 0) / prices.length;
  const stdDev = Math.sqrt(variance);

  return (stdDev / mean) * 100; // Coefficient of variation
}

/**
 * Predict future price based on historical data
 */
export function predictPrice(
  priceHistory: PricePoint[],
  daysAhead: number = 7
): PredictionResult {
  if (priceHistory.length === 0) {
    return {
      currentPrice: 0,
      predictedPrice: 0,
      trend: "stable",
      confidence: 0,
      reasoning: "No historical data available",
    };
  }

  // Sort by date
  const sortedHistory = [...priceHistory].sort(
    (a, b) => a.date.getTime() - b.date.getTime()
  );

  const prices = sortedHistory.map((p) => p.price);
  const currentPrice = prices[prices.length - 1];

  // Calculate trend
  const { trend, strength } = calculateTrend(prices);

  // Calculate volatility
  const volatility = calculateVolatility(prices);

  // Calculate moving averages
  const ma7 = calculateMovingAverage(prices, Math.min(7, prices.length));
  const ma14 = calculateMovingAverage(prices, Math.min(14, prices.length));

  // Predict future price
  let predictedPrice = currentPrice;
  let confidence = 50;

  if (trend === "up") {
    // Price is going up
    const avgIncrease = (ma7 - ma14) / ma14;
    const dailyIncrease = (avgIncrease / 7) * currentPrice;
    predictedPrice = currentPrice + dailyIncrease * daysAhead;
    confidence = Math.min(80, 50 + strength);
  } else if (trend === "down") {
    // Price is going down
    const avgDecrease = (ma14 - ma7) / ma14;
    const dailyDecrease = (avgDecrease / 7) * currentPrice;
    predictedPrice = currentPrice - dailyDecrease * daysAhead;
    confidence = Math.min(80, 50 + strength);
  } else {
    // Price is stable
    const avgChange = (ma7 - currentPrice) / currentPrice;
    predictedPrice = currentPrice * (1 + avgChange * 0.1); // Small adjustment
    confidence = Math.min(70, 50 + (100 - volatility));
  }

  // Adjust confidence based on volatility
  if (volatility > 10) {
    confidence = Math.max(30, confidence - 20); // High volatility = lower confidence
  }

  const reasoning = generateReasoning(
    trend,
    strength,
    volatility,
    prices.length,
    daysAhead
  );

  return {
    currentPrice,
    predictedPrice: Math.round(predictedPrice),
    trend,
    confidence: Math.round(confidence),
    reasoning,
  };
}

/**
 * Generate human-readable reasoning for prediction
 */
function generateReasoning(
  trend: string,
  strength: number,
  volatility: number,
  dataPoints: number,
  daysAhead: number
): string {
  let reason = `Based on ${dataPoints} price data points: `;

  if (trend === "up") {
    reason += `Price is trending upward with ${strength.toFixed(1)}% strength. `;
  } else if (trend === "down") {
    reason += `Price is trending downward with ${strength.toFixed(1)}% strength. `;
  } else {
    reason += `Price is relatively stable. `;
  }

  if (volatility > 10) {
    reason += `High price volatility (${volatility.toFixed(1)}%) suggests unpredictable fluctuations. `;
  } else if (volatility > 5) {
    reason += `Moderate volatility observed. `;
  } else {
    reason += `Price is stable with low volatility. `;
  }

  reason += `Prediction is for ${daysAhead} days ahead.`;

  return reason;
}

/**
 * Get seasonal adjustment factor
 * Useful for products with seasonal price patterns
 */
export function getSeasonalAdjustment(
  productCategory: string,
  month: number
): number {
  // Example: Electronics are cheaper during festival seasons
  const seasonalPatterns: Record<string, Record<number, number>> = {
    electronics: {
      1: 0.95, // January - post-holiday sales
      7: 0.98, // July - mid-year sales
      10: 0.92, // October - Diwali season
      11: 0.9, // November - Black Friday
      12: 0.88, // December - Year-end sales
    },
    fashion: {
      1: 0.9, // January - clearance
      4: 1.05, // April - summer collection
      10: 0.95, // October - festival season
      12: 0.85, // December - holiday sales
    },
  };

  const pattern = seasonalPatterns[productCategory.toLowerCase()] || {};
  return pattern[month] || 1.0;
}
