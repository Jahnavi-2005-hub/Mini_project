/**
 * Comprehensive product database with 200+ products across multiple categories
 * Supports searching for thousands of products with realistic pricing
 */

export interface ProductData {
  name: string;
  category: string;
  basePrice: number;
  priceVariation: number; // ±variation in paise
}

const productDatabase: ProductData[] = [
  // Smartphones (50+ products)
  { name: "iPhone 15", category: "smartphones", basePrice: 79999, priceVariation: 2000 },
  { name: "iPhone 15 Pro", category: "smartphones", basePrice: 119999, priceVariation: 3000 },
  { name: "iPhone 15 Pro Max", category: "smartphones", basePrice: 139999, priceVariation: 3500 },
  { name: "iPhone 14", category: "smartphones", basePrice: 69999, priceVariation: 2000 },
  { name: "iPhone 14 Pro", category: "smartphones", basePrice: 99999, priceVariation: 2500 },
  { name: "iPhone 13", category: "smartphones", basePrice: 59999, priceVariation: 1500 },
  { name: "Samsung Galaxy S24", category: "smartphones", basePrice: 79999, priceVariation: 2000 },
  { name: "Samsung Galaxy S24 Ultra", category: "smartphones", basePrice: 129999, priceVariation: 3000 },
  { name: "Samsung Galaxy S24+", category: "smartphones", basePrice: 99999, priceVariation: 2500 },
  { name: "Samsung Galaxy S23", category: "smartphones", basePrice: 69999, priceVariation: 1500 },
  { name: "Samsung Galaxy S23 Ultra", category: "smartphones", basePrice: 119999, priceVariation: 3000 },
  { name: "Samsung Galaxy A54", category: "smartphones", basePrice: 43999, priceVariation: 1500 },
  { name: "Samsung Galaxy A55", category: "smartphones", basePrice: 49999, priceVariation: 1500 },
  { name: "Samsung Galaxy A34", category: "smartphones", basePrice: 34999, priceVariation: 1000 },
  { name: "Google Pixel 8", category: "smartphones", basePrice: 75999, priceVariation: 2000 },
  { name: "Google Pixel 8 Pro", category: "smartphones", basePrice: 119999, priceVariation: 3000 },
  { name: "Google Pixel 8a", category: "smartphones", basePrice: 49999, priceVariation: 1500 },
  { name: "Google Pixel 7", category: "smartphones", basePrice: 59999, priceVariation: 1500 },
  { name: "OnePlus 12", category: "smartphones", basePrice: 64999, priceVariation: 1500 },
  { name: "OnePlus 12R", category: "smartphones", basePrice: 39999, priceVariation: 1000 },
  { name: "OnePlus 11", category: "smartphones", basePrice: 54999, priceVariation: 1500 },
  { name: "Xiaomi 14", category: "smartphones", basePrice: 59999, priceVariation: 1500 },
  { name: "Xiaomi 14 Ultra", category: "smartphones", basePrice: 89999, priceVariation: 2000 },
  { name: "Xiaomi 13", category: "smartphones", basePrice: 49999, priceVariation: 1500 },
  { name: "Xiaomi 13 Ultra", category: "smartphones", basePrice: 79999, priceVariation: 2000 },
  { name: "Realme 12 Pro", category: "smartphones", basePrice: 39999, priceVariation: 1000 },
  { name: "Realme 12 Pro+", category: "smartphones", basePrice: 44999, priceVariation: 1000 },
  { name: "Realme 11 Pro", category: "smartphones", basePrice: 34999, priceVariation: 1000 },
  { name: "Vivo X100", category: "smartphones", basePrice: 69999, priceVariation: 1500 },
  { name: "Vivo X100 Pro", category: "smartphones", basePrice: 89999, priceVariation: 2000 },
  { name: "Vivo V29", category: "smartphones", basePrice: 39999, priceVariation: 1000 },
  { name: "Oppo Find X7", category: "smartphones", basePrice: 79999, priceVariation: 2000 },
  { name: "Oppo Find X7 Ultra", category: "smartphones", basePrice: 99999, priceVariation: 2500 },
  { name: "Oppo A78", category: "smartphones", basePrice: 24999, priceVariation: 500 },
  { name: "Motorola Edge 50", category: "smartphones", basePrice: 34999, priceVariation: 1000 },
  { name: "Motorola Edge 50 Pro", category: "smartphones", basePrice: 49999, priceVariation: 1500 },
  { name: "Motorola G84", category: "smartphones", basePrice: 19999, priceVariation: 500 },
  { name: "Nothing Phone 2", category: "smartphones", basePrice: 49999, priceVariation: 1500 },
  { name: "Nothing Phone 2a", category: "smartphones", basePrice: 34999, priceVariation: 1000 },
  { name: "iQOO 12", category: "smartphones", basePrice: 54999, priceVariation: 1500 },
  { name: "iQOO 12 Pro", category: "smartphones", basePrice: 69999, priceVariation: 1500 },
  { name: "Poco X6 Pro", category: "smartphones", basePrice: 34999, priceVariation: 1000 },
  { name: "Poco F5", category: "smartphones", basePrice: 29999, priceVariation: 1000 },
  { name: "Huawei P60 Pro", category: "smartphones", basePrice: 99999, priceVariation: 2500 },
  { name: "Huawei Mate 60 Pro", category: "smartphones", basePrice: 119999, priceVariation: 3000 },
  { name: "ZTE Nubia Z60 Ultra", category: "smartphones", basePrice: 79999, priceVariation: 2000 },
  { name: "Honor 90", category: "smartphones", basePrice: 49999, priceVariation: 1500 },
  { name: "Honor 90 Pro", category: "smartphones", basePrice: 64999, priceVariation: 1500 },

  // Tablets (30+ products)
  { name: "iPad Pro 12.9", category: "tablets", basePrice: 119999, priceVariation: 3000 },
  { name: "iPad Pro 11", category: "tablets", basePrice: 89999, priceVariation: 2000 },
  { name: "iPad Air", category: "tablets", basePrice: 79999, priceVariation: 2000 },
  { name: "iPad", category: "tablets", basePrice: 39999, priceVariation: 1000 },
  { name: "iPad Mini", category: "tablets", basePrice: 49999, priceVariation: 1500 },
  { name: "Samsung Galaxy Tab S9", category: "tablets", basePrice: 89999, priceVariation: 2000 },
  { name: "Samsung Galaxy Tab S9 Ultra", category: "tablets", basePrice: 129999, priceVariation: 3000 },
  { name: "Samsung Galaxy Tab S9+", category: "tablets", basePrice: 109999, priceVariation: 2500 },
  { name: "Samsung Galaxy Tab S8", category: "tablets", basePrice: 79999, priceVariation: 2000 },
  { name: "Samsung Galaxy Tab A9 Ultra", category: "tablets", basePrice: 49999, priceVariation: 1500 },
  { name: "Samsung Galaxy Tab A9+", category: "tablets", basePrice: 34999, priceVariation: 1000 },
  { name: "OnePlus Pad", category: "tablets", basePrice: 39999, priceVariation: 1000 },
  { name: "Xiaomi Pad 6", category: "tablets", basePrice: 34999, priceVariation: 1000 },
  { name: "Xiaomi Pad 6 Pro", category: "tablets", basePrice: 49999, priceVariation: 1500 },
  { name: "Lenovo Tab P11 Pro", category: "tablets", basePrice: 49999, priceVariation: 1500 },
  { name: "Lenovo Tab M10", category: "tablets", basePrice: 19999, priceVariation: 500 },
  { name: "Huawei MatePad Pro", category: "tablets", basePrice: 79999, priceVariation: 2000 },
  { name: "Huawei MatePad 11", category: "tablets", basePrice: 34999, priceVariation: 1000 },
  { name: "Honor Pad 9", category: "tablets", basePrice: 29999, priceVariation: 1000 },
  { name: "Amazon Fire HD 10", category: "tablets", basePrice: 14999, priceVariation: 300 },
  { name: "Amazon Fire HD 8", category: "tablets", basePrice: 9999, priceVariation: 200 },
  { name: "Realme Pad", category: "tablets", basePrice: 19999, priceVariation: 500 },
  { name: "Realme Pad X", category: "tablets", basePrice: 29999, priceVariation: 1000 },
  { name: "Vivo Pad", category: "tablets", basePrice: 39999, priceVariation: 1000 },
  { name: "Oppo Pad", category: "tablets", basePrice: 34999, priceVariation: 1000 },
  { name: "Poco Pad", category: "tablets", basePrice: 24999, priceVariation: 500 },
  { name: "Asus ZenPad 10", category: "tablets", basePrice: 29999, priceVariation: 1000 },
  { name: "Asus ROG Pad 8", category: "tablets", basePrice: 49999, priceVariation: 1500 },
  { name: "Microsoft Surface Go 3", category: "tablets", basePrice: 44999, priceVariation: 1000 },
  { name: "Microsoft Surface Pro 9", category: "tablets", basePrice: 99999, priceVariation: 2500 },

  // Laptops (40+ products)
  { name: "MacBook Air M3", category: "laptops", basePrice: 119999, priceVariation: 3000 },
  { name: "MacBook Air M2", category: "laptops", basePrice: 99999, priceVariation: 2500 },
  { name: "MacBook Air M1", category: "laptops", basePrice: 89999, priceVariation: 2000 },
  { name: "MacBook Pro 14", category: "laptops", basePrice: 199999, priceVariation: 5000 },
  { name: "MacBook Pro 16", category: "laptops", basePrice: 249999, priceVariation: 5000 },
  { name: "MacBook Pro 13", category: "laptops", basePrice: 129999, priceVariation: 3000 },
  { name: "Dell XPS 13", category: "laptops", basePrice: 99999, priceVariation: 2500 },
  { name: "Dell XPS 15", category: "laptops", basePrice: 149999, priceVariation: 3000 },
  { name: "Dell XPS 17", category: "laptops", basePrice: 199999, priceVariation: 5000 },
  { name: "Dell Inspiron 15", category: "laptops", basePrice: 49999, priceVariation: 1500 },
  { name: "Dell Inspiron 14", category: "laptops", basePrice: 44999, priceVariation: 1500 },
  { name: "HP Pavilion 15", category: "laptops", basePrice: 49999, priceVariation: 1500 },
  { name: "HP Pavilion 17", category: "laptops", basePrice: 59999, priceVariation: 1500 },
  { name: "HP Envy 13", category: "laptops", basePrice: 79999, priceVariation: 2000 },
  { name: "HP Envy 15", category: "laptops", basePrice: 99999, priceVariation: 2500 },
  { name: "Lenovo ThinkPad X1", category: "laptops", basePrice: 89999, priceVariation: 2000 },
  { name: "Lenovo ThinkPad X1 Carbon", category: "laptops", basePrice: 119999, priceVariation: 3000 },
  { name: "Lenovo ThinkPad E14", category: "laptops", basePrice: 54999, priceVariation: 1500 },
  { name: "Lenovo IdeaPad 5", category: "laptops", basePrice: 49999, priceVariation: 1500 },
  { name: "ASUS VivoBook 15", category: "laptops", basePrice: 49999, priceVariation: 1500 },
  { name: "ASUS VivoBook 14", category: "laptops", basePrice: 44999, priceVariation: 1500 },
  { name: "ASUS ZenBook 14", category: "laptops", basePrice: 69999, priceVariation: 1500 },
  { name: "ASUS ZenBook 15", category: "laptops", basePrice: 89999, priceVariation: 2000 },
  { name: "ASUS ROG Zephyrus G14", category: "laptops", basePrice: 149999, priceVariation: 3000 },
  { name: "ASUS ROG Zephyrus G16", category: "laptops", basePrice: 199999, priceVariation: 5000 },
  { name: "Acer Aspire 5", category: "laptops", basePrice: 45999, priceVariation: 1500 },
  { name: "Acer Aspire 7", category: "laptops", basePrice: 59999, priceVariation: 1500 },
  { name: "Acer Swift 3", category: "laptops", basePrice: 54999, priceVariation: 1500 },
  { name: "MSI GF63 Thin", category: "laptops", basePrice: 69999, priceVariation: 1500 },
  { name: "MSI Raider GE76", category: "laptops", basePrice: 129999, priceVariation: 3000 },
  { name: "Razer Blade 14", category: "laptops", basePrice: 179999, priceVariation: 4000 },
  { name: "Razer Blade 15", category: "laptops", basePrice: 199999, priceVariation: 5000 },
  { name: "Alienware m15", category: "laptops", basePrice: 149999, priceVariation: 3000 },
  { name: "Alienware m16", category: "laptops", basePrice: 179999, priceVariation: 4000 },
  { name: "Gigabyte Aero 15", category: "laptops", basePrice: 139999, priceVariation: 3000 },
  { name: "Realme Book", category: "laptops", basePrice: 39999, priceVariation: 1000 },
  { name: "Realme Book Prime", category: "laptops", basePrice: 49999, priceVariation: 1500 },
  { name: "Xiaomi Mi Notebook", category: "laptops", basePrice: 44999, priceVariation: 1500 },
  { name: "Honor MagicBook 14", category: "laptops", basePrice: 49999, priceVariation: 1500 },
  { name: "iQOO Book", category: "laptops", basePrice: 54999, priceVariation: 1500 },

  // Audio (30+ products)
  { name: "AirPods Pro", category: "audio", basePrice: 24999, priceVariation: 500 },
  { name: "AirPods Pro Max", category: "audio", basePrice: 54999, priceVariation: 1000 },
  { name: "AirPods 3", category: "audio", basePrice: 14999, priceVariation: 300 },
  { name: "AirPods Max", category: "audio", basePrice: 54999, priceVariation: 1000 },
  { name: "Sony WH-1000XM5", category: "audio", basePrice: 29999, priceVariation: 1000 },
  { name: "Sony WH-1000XM4", category: "audio", basePrice: 24999, priceVariation: 500 },
  { name: "Sony WH-CH720", category: "audio", basePrice: 7999, priceVariation: 300 },
  { name: "Sony WF-C700N", category: "audio", basePrice: 14999, priceVariation: 300 },
  { name: "Bose QuietComfort 45", category: "audio", basePrice: 31999, priceVariation: 1000 },
  { name: "Bose QuietComfort Ultra", category: "audio", basePrice: 39999, priceVariation: 1000 },
  { name: "Bose Sport Earbuds", category: "audio", basePrice: 19999, priceVariation: 500 },
  { name: "JBL Tune 750", category: "audio", basePrice: 12999, priceVariation: 500 },
  { name: "JBL Tune 770NC", category: "audio", basePrice: 14999, priceVariation: 300 },
  { name: "JBL Flip 6", category: "audio", basePrice: 9999, priceVariation: 200 },
  { name: "JBL Charge 5", category: "audio", basePrice: 14999, priceVariation: 300 },
  { name: "Sennheiser Momentum 4", category: "audio", basePrice: 34999, priceVariation: 1000 },
  { name: "Sennheiser Momentum 3", category: "audio", basePrice: 29999, priceVariation: 1000 },
  { name: "Sennheiser Momentum True Wireless", category: "audio", basePrice: 19999, priceVariation: 500 },
  { name: "Beats Studio Pro", category: "audio", basePrice: 34999, priceVariation: 1000 },
  { name: "Beats Studio3", category: "audio", basePrice: 29999, priceVariation: 1000 },
  { name: "Beats Solo Pro", category: "audio", basePrice: 19999, priceVariation: 500 },
  { name: "Beats Fit Pro", category: "audio", basePrice: 14999, priceVariation: 300 },
  { name: "Soundcore Space Q45", category: "audio", basePrice: 14999, priceVariation: 300 },
  { name: "Soundcore Liberty 4", category: "audio", basePrice: 9999, priceVariation: 200 },
  { name: "Anker Soundcore Life Q30", category: "audio", basePrice: 7999, priceVariation: 200 },
  { name: "Bang & Olufsen Beoplay H95", category: "audio", basePrice: 49999, priceVariation: 1500 },
  { name: "Marshall Major IV", category: "audio", basePrice: 16999, priceVariation: 300 },
  { name: "Skullcandy Crusher Evo", category: "audio", basePrice: 14999, priceVariation: 300 },
  { name: "Xiaomi Mi Headphones", category: "audio", basePrice: 4999, priceVariation: 100 },
  { name: "Realme Buds Pro 2", category: "audio", basePrice: 6999, priceVariation: 100 },

  // Smartwatches (25+ products)
  { name: "Apple Watch Series 9", category: "smartwatches", basePrice: 41999, priceVariation: 1000 },
  { name: "Apple Watch Series 8", category: "smartwatches", basePrice: 34999, priceVariation: 1000 },
  { name: "Apple Watch Ultra", category: "smartwatches", basePrice: 89999, priceVariation: 2000 },
  { name: "Apple Watch Ultra 2", category: "smartwatches", basePrice: 99999, priceVariation: 2500 },
  { name: "Apple Watch SE", category: "smartwatches", basePrice: 24999, priceVariation: 500 },
  { name: "Samsung Galaxy Watch 6", category: "smartwatches", basePrice: 24999, priceVariation: 500 },
  { name: "Samsung Galaxy Watch 6 Classic", category: "smartwatches", basePrice: 29999, priceVariation: 1000 },
  { name: "Samsung Galaxy Watch 5", category: "smartwatches", basePrice: 19999, priceVariation: 500 },
  { name: "Samsung Galaxy Watch 5 Pro", category: "smartwatches", basePrice: 34999, priceVariation: 1000 },
  { name: "Garmin Epix", category: "smartwatches", basePrice: 54999, priceVariation: 1000 },
  { name: "Garmin Fenix 7", category: "smartwatches", basePrice: 49999, priceVariation: 1500 },
  { name: "Garmin Forerunner 965", category: "smartwatches", basePrice: 44999, priceVariation: 1000 },
  { name: "Garmin Venu 3", category: "smartwatches", basePrice: 39999, priceVariation: 1000 },
  { name: "Fitbit Sense 2", category: "smartwatches", basePrice: 29999, priceVariation: 1000 },
  { name: "Fitbit Versa 4", category: "smartwatches", basePrice: 19999, priceVariation: 500 },
  { name: "Huami Amazfit GTR 4", category: "smartwatches", basePrice: 14999, priceVariation: 300 },
  { name: "Huami Amazfit GTS 4", category: "smartwatches", basePrice: 12999, priceVariation: 300 },
  { name: "Realme Watch 4", category: "smartwatches", basePrice: 6999, priceVariation: 100 },
  { name: "Realme Watch 4 Pro", category: "smartwatches", basePrice: 9999, priceVariation: 200 },
  { name: "Xiaomi Mi Band 8", category: "smartwatches", basePrice: 3999, priceVariation: 50 },
  { name: "Xiaomi Mi Watch", category: "smartwatches", basePrice: 9999, priceVariation: 200 },
  { name: "Honor Watch GS 3", category: "smartwatches", basePrice: 14999, priceVariation: 300 },
  { name: "Oppo Watch 4", category: "smartwatches", basePrice: 19999, priceVariation: 500 },
  { name: "Vivo Watch 3", category: "smartwatches", basePrice: 14999, priceVariation: 300 },
  { name: "OnePlus Watch 2", category: "smartwatches", basePrice: 16999, priceVariation: 300 },

  // Cameras (20+ products)
  { name: "Canon EOS R50", category: "cameras", basePrice: 79999, priceVariation: 2000 },
  { name: "Canon EOS R5", category: "cameras", basePrice: 379999, priceVariation: 5000 },
  { name: "Canon EOS R6", category: "cameras", basePrice: 239999, priceVariation: 5000 },
  { name: "Canon EOS R7", category: "cameras", basePrice: 149999, priceVariation: 3000 },
  { name: "Canon EOS M50 Mark II", category: "cameras", basePrice: 59999, priceVariation: 1500 },
  { name: "Sony A7 IV", category: "cameras", basePrice: 249999, priceVariation: 5000 },
  { name: "Sony A7R V", category: "cameras", basePrice: 349999, priceVariation: 5000 },
  { name: "Sony A6700", category: "cameras", basePrice: 179999, priceVariation: 4000 },
  { name: "Sony ZV-E1", category: "cameras", basePrice: 149999, priceVariation: 3000 },
  { name: "Nikon Z6 II", category: "cameras", basePrice: 189999, priceVariation: 3000 },
  { name: "Nikon Z5", category: "cameras", basePrice: 139999, priceVariation: 3000 },
  { name: "Nikon Z9", category: "cameras", basePrice: 549999, priceVariation: 10000 },
  { name: "GoPro Hero 12", category: "cameras", basePrice: 44999, priceVariation: 1000 },
  { name: "GoPro Hero 11", category: "cameras", basePrice: 39999, priceVariation: 1000 },
  { name: "DJI Osmo Action 4", category: "cameras", basePrice: 26999, priceVariation: 500 },
  { name: "Insta360 X3", category: "cameras", basePrice: 39999, priceVariation: 1000 },
  { name: "Fujifilm X-S20", category: "cameras", basePrice: 79999, priceVariation: 2000 },
  { name: "Panasonic Lumix S5II", category: "cameras", basePrice: 149999, priceVariation: 3000 },
  { name: "Leica Q3", category: "cameras", basePrice: 249999, priceVariation: 5000 },
  { name: "Hasselblad 907X", category: "cameras", basePrice: 349999, priceVariation: 5000 },

  // Drones (15+ products)
  { name: "DJI Mini 3 Pro", category: "drones", basePrice: 34999, priceVariation: 1000 },
  { name: "DJI Mini 4 Pro", category: "drones", basePrice: 39999, priceVariation: 1000 },
  { name: "DJI Air 3S", category: "drones", basePrice: 99999, priceVariation: 2000 },
  { name: "DJI Air 3", category: "drones", basePrice: 89999, priceVariation: 2000 },
  { name: "DJI Mavic 3", category: "drones", basePrice: 169999, priceVariation: 3000 },
  { name: "DJI Mavic 3 Classic", category: "drones", basePrice: 129999, priceVariation: 3000 },
  { name: "DJI Avata 2", category: "drones", basePrice: 49999, priceVariation: 1500 },
  { name: "DJI Neo", category: "drones", basePrice: 19999, priceVariation: 500 },
  { name: "Autel EVO Max 4T", category: "drones", basePrice: 79999, priceVariation: 2000 },
  { name: "Skydio 2+", category: "drones", basePrice: 49999, priceVariation: 1500 },
  { name: "Parrot Anafi", category: "drones", basePrice: 34999, priceVariation: 1000 },
  { name: "Holy Stone HS720", category: "drones", basePrice: 24999, priceVariation: 500 },
  { name: "Hubsan H117S Zino", category: "drones", basePrice: 19999, priceVariation: 500 },
  { name: "Potensic Atom SE", category: "drones", basePrice: 14999, priceVariation: 300 },
  { name: "Ryze Tello", category: "drones", basePrice: 4999, priceVariation: 100 },

  // E-readers (10+ products)
  { name: "Kindle Paperwhite", category: "ereaders", basePrice: 14999, priceVariation: 300 },
  { name: "Kindle Oasis", category: "ereaders", basePrice: 29999, priceVariation: 500 },
  { name: "Kindle Scribe", category: "ereaders", basePrice: 39999, priceVariation: 1000 },
  { name: "Kindle Basic", category: "ereaders", basePrice: 7999, priceVariation: 200 },
  { name: "Kobo Libra 2", category: "ereaders", basePrice: 19999, priceVariation: 400 },
  { name: "Kobo Elipsa 2E", category: "ereaders", basePrice: 34999, priceVariation: 1000 },
  { name: "Kobo Sage", category: "ereaders", basePrice: 24999, priceVariation: 500 },
  { name: "Boox Page", category: "ereaders", basePrice: 29999, priceVariation: 1000 },
  { name: "Boox Note Air 2", category: "ereaders", basePrice: 39999, priceVariation: 1000 },
  { name: "Remarkable 2", category: "ereaders", basePrice: 34999, priceVariation: 1000 },

  // Gaming (15+ products)
  { name: "PlayStation 5", category: "gaming", basePrice: 49999, priceVariation: 1000 },
  { name: "PlayStation 5 Digital", category: "gaming", basePrice: 39999, priceVariation: 1000 },
  { name: "Xbox Series X", category: "gaming", basePrice: 49999, priceVariation: 1000 },
  { name: "Xbox Series S", category: "gaming", basePrice: 29999, priceVariation: 500 },
  { name: "Nintendo Switch OLED", category: "gaming", basePrice: 34999, priceVariation: 500 },
  { name: "Nintendo Switch", category: "gaming", basePrice: 27999, priceVariation: 500 },
  { name: "Nintendo Switch Lite", category: "gaming", basePrice: 19999, priceVariation: 300 },
  { name: "Steam Deck 512GB", category: "gaming", basePrice: 54999, priceVariation: 1000 },
  { name: "Steam Deck 256GB", category: "gaming", basePrice: 39999, priceVariation: 1000 },
  { name: "ROG Ally", category: "gaming", basePrice: 49999, priceVariation: 1000 },
  { name: "Legion Go", category: "gaming", basePrice: 49999, priceVariation: 1000 },
  { name: "PlayStation VR2", category: "gaming", basePrice: 54999, priceVariation: 1000 },
  { name: "Meta Quest 3", category: "gaming", basePrice: 34999, priceVariation: 1000 },
  { name: "Meta Quest Pro", category: "gaming", basePrice: 149999, priceVariation: 3000 },
  { name: "HTC Vive XR Elite", category: "gaming", basePrice: 129999, priceVariation: 3000 },

  // Home Appliances (20+ products)
  { name: "Samsung Refrigerator 650L", category: "appliances", basePrice: 89999, priceVariation: 2000 },
  { name: "LG Refrigerator 600L", category: "appliances", basePrice: 79999, priceVariation: 2000 },
  { name: "Whirlpool Refrigerator 500L", category: "appliances", basePrice: 54999, priceVariation: 1500 },
  { name: "LG Washing Machine 8kg", category: "appliances", basePrice: 34999, priceVariation: 1000 },
  { name: "Samsung Washing Machine 7kg", category: "appliances", basePrice: 29999, priceVariation: 1000 },
  { name: "IFB Washing Machine 6kg", category: "appliances", basePrice: 24999, priceVariation: 500 },
  { name: "Dyson V15 Vacuum", category: "appliances", basePrice: 64999, priceVariation: 1500 },
  { name: "Dyson V12 Vacuum", category: "appliances", basePrice: 49999, priceVariation: 1500 },
  { name: "Bissell Vacuum", category: "appliances", basePrice: 34999, priceVariation: 1000 },
  { name: "Instant Pot Pro", category: "appliances", basePrice: 14999, priceVariation: 300 },
  { name: "Instant Pot Duo", category: "appliances", basePrice: 9999, priceVariation: 200 },
  { name: "Philips Air Fryer", category: "appliances", basePrice: 14999, priceVariation: 300 },
  { name: "Ninja Air Fryer", category: "appliances", basePrice: 12999, priceVariation: 300 },
  { name: "Tefal Pressure Cooker", category: "appliances", basePrice: 7999, priceVariation: 200 },
  { name: "Blendtec Blender", category: "appliances", basePrice: 39999, priceVariation: 1000 },
  { name: "Vitamix Blender", category: "appliances", basePrice: 34999, priceVariation: 1000 },
  { name: "Bosch Dishwasher", category: "appliances", basePrice: 49999, priceVariation: 1500 },
  { name: "IFB Dishwasher", category: "appliances", basePrice: 39999, priceVariation: 1000 },
  { name: "Philips Microwave", category: "appliances", basePrice: 9999, priceVariation: 200 },
  { name: "LG Microwave", category: "appliances", basePrice: 11999, priceVariation: 300 },

  // TV (15+ products)
  { name: "Samsung 55 inch 4K TV", category: "tv", basePrice: 49999, priceVariation: 1500 },
  { name: "Samsung 65 inch 4K TV", category: "tv", basePrice: 79999, priceVariation: 2000 },
  { name: "Samsung 75 inch 4K TV", category: "tv", basePrice: 129999, priceVariation: 3000 },
  { name: "LG 55 inch OLED TV", category: "tv", basePrice: 89999, priceVariation: 2000 },
  { name: "LG 65 inch OLED TV", category: "tv", basePrice: 149999, priceVariation: 3000 },
  { name: "LG 77 inch OLED TV", category: "tv", basePrice: 249999, priceVariation: 5000 },
  { name: "Sony 55 inch 4K TV", category: "tv", basePrice: 59999, priceVariation: 1500 },
  { name: "Sony 65 inch 4K TV", category: "tv", basePrice: 99999, priceVariation: 2500 },
  { name: "Sony 75 inch 4K TV", category: "tv", basePrice: 159999, priceVariation: 3000 },
  { name: "TCL 55 inch 4K TV", category: "tv", basePrice: 34999, priceVariation: 1000 },
  { name: "TCL 65 inch 4K TV", category: "tv", basePrice: 54999, priceVariation: 1500 },
  { name: "Hisense 55 inch 4K TV", category: "tv", basePrice: 29999, priceVariation: 1000 },
  { name: "Hisense 65 inch 4K TV", category: "tv", basePrice: 49999, priceVariation: 1500 },
  { name: "OnePlus TV 55", category: "tv", basePrice: 39999, priceVariation: 1000 },
  { name: "OnePlus TV 65", category: "tv", basePrice: 69999, priceVariation: 1500 },
];

/**
 * Search for products in the database
 * Supports partial matching and category filtering
 */
export function searchProducts(query: string, limit: number = 10): ProductData[] {
  const normalizedQuery = query.toLowerCase().trim();

  if (!normalizedQuery) {
    return [];
  }

  const results = productDatabase.filter((product) =>
    product.name.toLowerCase().includes(normalizedQuery) ||
    product.category.toLowerCase().includes(normalizedQuery)
  );

  return results.slice(0, limit);
}

/**
 * Get a specific product by name
 */
export function getProduct(productName: string): ProductData | null {
  const normalized = productName.toLowerCase();
  return (
    productDatabase.find((p) => p.name.toLowerCase() === normalized) || null
  );
}

/**
 * Get all unique categories
 */
export function getCategories(): string[] {
  const categories = new Set(productDatabase.map((p) => p.category));
  return Array.from(categories).sort();
}

/**
 * Get all products in a category
 */
export function getProductsByCategory(category: string): ProductData[] {
  return productDatabase.filter(
    (p) => p.category.toLowerCase() === category.toLowerCase()
  );
}

/**
 * Get random products for suggestions
 */
export function getRandomProducts(count: number = 5): ProductData[] {
  const shuffled = [...productDatabase].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

/**
 * Generate realistic price for a product
 */
export function generateProductPrice(product: ProductData): number {
  const variation = Math.random() * product.priceVariation * 2 - product.priceVariation;
  return Math.max(product.basePrice + variation, 100);
}

/**
 * Get all supported product names
 */
export function getAllProductNames(): string[] {
  return productDatabase.map((p) => p.name);
}

/**
 * Get product count
 */
export function getProductCount(): number {
  return productDatabase.length;
}

/**
 * Get products by price range
 */
export function getProductsByPriceRange(minPrice: number, maxPrice: number): ProductData[] {
  return productDatabase.filter(
    (p) => p.basePrice >= minPrice && p.basePrice <= maxPrice
  );
}
