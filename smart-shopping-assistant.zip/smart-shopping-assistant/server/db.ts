import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Import additional schema types
import { desc } from 'drizzle-orm';
import { priceComparisons, pricePredictions, userSavings, InsertPriceComparison, InsertPricePrediction, priceHistory, InsertPriceHistory, productCache, InsertProductCache } from '../drizzle/schema';

export async function getUserSavings(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(userSavings).where(eq(userSavings.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getOrCreateUserSavings(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  let savings = await getUserSavings(userId);
  if (!savings) {
    await db.insert(userSavings).values({ userId, totalSavings: 0, comparisonsCount: 0 });
    savings = await getUserSavings(userId);
  }
  return savings;
}

export async function getUserComparisons(userId: number, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(priceComparisons).where(eq(priceComparisons.userId, userId)).orderBy(desc(priceComparisons.createdAt)).limit(limit);
}

export async function getUserPredictions(userId: number, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pricePredictions).where(eq(pricePredictions.userId, userId)).orderBy(desc(pricePredictions.createdAt)).limit(limit);
}

export async function createComparison(data: InsertPriceComparison) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.insert(priceComparisons).values(data);
  
  // Update user savings
  const savings = await getOrCreateUserSavings(data.userId);
  if (savings && data.savingsAmount) {
    await db.update(userSavings)
      .set({
        totalSavings: savings.totalSavings + data.savingsAmount,
        comparisonsCount: savings.comparisonsCount + 1,
      })
      .where(eq(userSavings.userId, data.userId));
  }
  
  return result;
}

export async function createPrediction(data: InsertPricePrediction) {
  const db = await getDb();
  if (!db) return undefined;
  return db.insert(pricePredictions).values(data);
}

// Price History functions
export async function addPriceHistory(data: InsertPriceHistory) {
  const db = await getDb();
  if (!db) return undefined;
  return db.insert(priceHistory).values(data);
}

export async function getPriceHistory(productName: string, platform: string, days: number = 30) {
  const db = await getDb();
  if (!db) return [];
  
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);
  
  return db
    .select()
    .from(priceHistory)
    .where(
      eq(priceHistory.productName, productName) &&
      eq(priceHistory.platform, platform)
    )
    .orderBy(desc(priceHistory.fetchedAt))
    .limit(100);
}

// Product Cache functions
export async function getProductCache(productName: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db
    .select()
    .from(productCache)
    .where(eq(productCache.productName, productName))
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertProductCache(data: InsertProductCache) {
  const db = await getDb();
  if (!db) return undefined;
  
  return db
    .insert(productCache)
    .values(data)
    .onDuplicateKeyUpdate({
      set: {
        amazonProductId: data.amazonProductId,
        flipkartProductId: data.flipkartProductId,
        lastFetched: new Date(),
      },
    });
}


// Budget Alert functions
import { budgetAlerts, InsertBudgetAlert } from '../drizzle/schema';

export async function createBudgetAlert(data: InsertBudgetAlert) {
  const db = await getDb();
  if (!db) return undefined;
  return db.insert(budgetAlerts).values(data);
}

export async function getUserBudgetAlerts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(budgetAlerts).where(eq(budgetAlerts.userId, userId)).orderBy(desc(budgetAlerts.createdAt));
}

export async function getBudgetAlert(alertId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(budgetAlerts).where(eq(budgetAlerts.id, alertId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateBudgetAlert(alertId: number, data: Partial<InsertBudgetAlert>) {
  const db = await getDb();
  if (!db) return undefined;
  return db.update(budgetAlerts).set(data).where(eq(budgetAlerts.id, alertId));
}

export async function deleteBudgetAlert(alertId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return db.delete(budgetAlerts).where(eq(budgetAlerts.id, alertId));
}

export async function getActiveBudgetAlerts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(budgetAlerts).where(eq(budgetAlerts.userId, userId));
}
