import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { useLocation } from "wouter";
import { APP_LOGO, APP_TITLE } from "@/const";
import { Link } from "wouter";
import { ShoppingCart, TrendingDown, BarChart3, Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function Comparison() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<any>(null);

  const { data: comparisons, isLoading, refetch } = trpc.comparison.list.useQuery();
  const { data: supportedProducts } = trpc.products.getSupportedProducts.useQuery();
  
  const searchMutation = trpc.comparison.search.useQuery(
    { productName: searchQuery },
    { enabled: false }
  );

  const createMutation = trpc.comparison.create.useMutation({
    onSuccess: () => {
      toast.success("Comparison added successfully!");
      setSearchQuery("");
      setSearchResult(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to add comparison");
    },
  });

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      toast.error("Please enter a product name");
      return;
    }

    setIsSearching(true);
    try {
      const result = await searchMutation.refetch();
      if (result.data) {
        setSearchResult(result.data);
      }
    } catch (error) {
      toast.error("Failed to search product");
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddComparison = () => {
    if (!searchResult) return;

    createMutation.mutate({
      productName: searchResult.productName,
      amazonPrice: searchResult.amazon?.price,
      flipkartPrice: searchResult.flipkart?.price,
      amazonUrl: searchResult.amazon?.url,
      flipkartUrl: searchResult.flipkart?.url,
    });
  };

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            {APP_LOGO && <img src={APP_LOGO} alt="Logo" className="h-8 w-8" />}
            <h1 className="text-2xl font-bold text-indigo-600">{APP_TITLE}</h1>
          </div>
          <div className="flex gap-4 items-center">
            <Link href="/comparison">
              <Button variant="ghost">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Compare
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost">
                <BarChart3 className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <Link href="/prediction">
              <Button variant="ghost">
                <TrendingDown className="h-4 w-4 mr-2" />
                Predict
              </Button>
            </Link>
            <span className="text-gray-600">{user?.name}</span>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Price Comparison</h2>

        {/* Search Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Search & Compare Prices</CardTitle>
            <CardDescription>
              Enter a product name to automatically fetch and compare prices from Amazon and Flipkart
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Product Name
                </label>
                <div className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="e.g., iPhone 15, Samsung Galaxy S24, AirPods Pro"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    list="products"
                  />
                  <datalist id="products">
                    {supportedProducts?.map((product) => (
                      <option key={product} value={product} />
                    ))}
                  </datalist>
                  <Button
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-700"
                    disabled={isSearching}
                  >
                    {isSearching ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Searching...
                      </>
                    ) : (
                      "Search"
                    )}
                  </Button>
                </div>
                {supportedProducts && supportedProducts.length > 0 && (
                  <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-xs font-semibold text-blue-900 mb-2">Popular Products:</p>
                    <div className="flex flex-wrap gap-2">
                      {supportedProducts.slice(0, 6).map((product) => (
                        <button
                          key={product}
                          onClick={() => setSearchQuery(product)}
                          className="text-xs px-2 py-1 bg-white border border-blue-300 rounded hover:bg-blue-100 text-blue-700 transition"
                        >
                          {product}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Search Results */}
        {searchResult && (
          <Card className="mb-8 border-2 border-indigo-200 bg-indigo-50">
            <CardHeader>
              <CardTitle>{searchResult.productName}</CardTitle>
              <CardDescription>Real-time prices from Amazon and Flipkart</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                {/* Amazon Price */}
                <div className="border rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">Amazon</h3>
                    {searchResult.amazon && (
                      <span className="text-sm text-gray-600">
                        ⭐ {searchResult.amazon.rating?.toFixed(1) || "N/A"}
                      </span>
                    )}
                  </div>
                  {searchResult.amazon ? (
                    <div>
                      <div className="text-3xl font-bold text-indigo-600 mb-2">
                        ₹{searchResult.amazon.price.toFixed(0)}
                      </div>
                      <div className="flex gap-2 mb-3">
                        {searchResult.amazon.availability && (
                          <span className="inline-block px-3 py-1 rounded-full text-sm font-semibold bg-green-100 text-green-800">
                            In Stock
                          </span>
                        )}
                      </div>
                      {searchResult.amazon.url && (
                        <a href={searchResult.amazon.url} target="_blank" rel="noopener noreferrer">
                          <Button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white mt-2">
                            View on Amazon →
                          </Button>
                        </a>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-gray-600">
                      <AlertCircle className="h-4 w-4" />
                      <span>Product not found</span>
                    </div>
                  )}
                </div>

                {/* Flipkart Price */}
                <div className="border rounded-lg p-4 bg-white">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">Flipkart</h3>
                    {searchResult.flipkart && (
                      <span className="text-sm text-gray-600">
                        ⭐ {searchResult.flipkart.rating?.toFixed(1) || "N/A"}
                      </span>
                    )}
                  </div>
                  {searchResult.flipkart ? (
                    <div>
                      <div className="text-3xl font-bold text-orange-600 mb-2">
                        ₹{searchResult.flipkart.price.toFixed(0)}
                      </div>
                      <div className="flex gap-2 mb-3">
                        {searchResult.flipkart.availability && (
                          <span className="inline-block px-3 py-1 rounded-full text-sm font-semibold bg-green-100 text-green-800">
                            In Stock
                          </span>
                        )}
                      </div>
                      {searchResult.flipkart.url && (
                        <a href={searchResult.flipkart.url} target="_blank" rel="noopener noreferrer">
                          <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white mt-2">
                            View on Flipkart →
                          </Button>
                        </a>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-gray-600">
                      <AlertCircle className="h-4 w-4" />
                      <span>Product not found</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Comparison Result */}
              {searchResult.cheaper && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-3 w-3 rounded-full bg-green-600"></div>
                    <h4 className="font-semibold text-green-900">Best Deal</h4>
                  </div>
                  <p className="text-green-800">
                    <span className="font-bold">{searchResult.cheaper.toUpperCase()}</span> is cheaper by{" "}
                    <span className="font-bold text-lg">₹{searchResult.savings.toFixed(0)}</span>
                  </p>
                </div>
              )}

              <Button
                onClick={handleAddComparison}
                className="w-full bg-indigo-600 hover:bg-indigo-700"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? "Adding..." : "Add to Comparisons"}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Comparisons List */}
        <div>
          <h3 className="text-xl font-bold text-gray-900 mb-4">Your Comparisons</h3>
          {isLoading ? (
            <div className="text-center py-8">
              <Loader2 className="h-8 w-8 animate-spin mx-auto text-indigo-600" />
              <p className="text-gray-600 mt-2">Loading comparisons...</p>
            </div>
          ) : comparisons && comparisons.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {comparisons.map((comparison) => (
                <Card key={comparison.id}>
                  <CardHeader>
                    <CardTitle className="text-lg">{comparison.productName}</CardTitle>
                    <CardDescription>
                      {new Date(comparison.comparisonDate).toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Amazon:</span>
                        <span className="font-semibold">
                          {comparison.amazonPrice ? `₹${(comparison.amazonPrice / 100).toFixed(0)}` : "N/A"}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Flipkart:</span>
                        <span className="font-semibold">
                          {comparison.flipkartPrice ? `₹${(comparison.flipkartPrice / 100).toFixed(0)}` : "N/A"}
                        </span>
                      </div>
                      {comparison.cheaperPlatform && (
                        <>
                          <div className="border-t pt-2 mt-2">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Cheaper on:</span>
                              <span className="font-semibold text-green-600">
                                {comparison.cheaperPlatform.toUpperCase()}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">You Save:</span>
                              <span className="font-semibold text-green-600">
                                ₹{comparison.savingsAmount ? (comparison.savingsAmount / 100).toFixed(0) : "0"}
                              </span>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <p className="text-gray-600 mb-4">No comparisons yet. Search for a product to get started!</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
