import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { useLocation } from "wouter";
import { APP_LOGO, APP_TITLE } from "@/const";
import { Link } from "wouter";
import { ShoppingCart, TrendingDown, BarChart3, Loader2, AlertCircle, Trash2, Bell, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function BudgetAlerts() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [productName, setProductName] = useState("");
  const [platform, setPlatform] = useState<"amazon" | "flipkart">("amazon");
  const [budgetPrice, setBudgetPrice] = useState("");
  const [currentPrice, setCurrentPrice] = useState("");

  const { data: alerts, isLoading, refetch } = trpc.budgetAlert.list.useQuery();
  const { data: supportedProducts } = trpc.products.getSupportedProducts.useQuery();

  const createMutation = trpc.budgetAlert.create.useMutation({
    onSuccess: () => {
      toast.success("Budget alert created! You'll be notified when the price drops.");
      setProductName("");
      setBudgetPrice("");
      setCurrentPrice("");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create budget alert");
    },
  });

  const deleteMutation = trpc.budgetAlert.delete.useMutation({
    onSuccess: () => {
      toast.success("Budget alert deleted");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete alert");
    },
  });

  const handleCreateAlert = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!productName.trim() || !budgetPrice || !currentPrice) {
      toast.error("Please fill in all fields");
      return;
    }

    const budget = parseFloat(budgetPrice);
    const current = parseFloat(currentPrice);

    if (budget <= 0 || current <= 0) {
      toast.error("Prices must be greater than 0");
      return;
    }

    createMutation.mutate({
      productName: productName.trim(),
      platform,
      budgetPrice: budget,
      currentPrice: current,
    });
  };

  const handleDeleteAlert = (alertId: number) => {
    if (confirm("Are you sure you want to delete this alert?")) {
      deleteMutation.mutate({ alertId });
    }
  };

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const getPriceDropPercentage = (current: number, budget: number) => {
    if (current === 0) return 0;
    return Math.round(((current - budget) / current) * 100);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            {APP_LOGO && <img src={APP_LOGO} alt="Logo" className="h-8 w-8" />}
            <h1 className="text-2xl font-bold text-indigo-600">{APP_TITLE}</h1>
          </div>
          <div className="flex gap-4 items-center">
            <Link href="/comparison">
              <Button variant="ghost">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Compare
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost">
                <BarChart3 className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <Link href="/prediction">
              <Button variant="ghost">
                <TrendingDown className="h-4 w-4 mr-2" />
                Predict
              </Button>
            </Link>
            <Link href="/budget-alerts">
              <Button variant="ghost" className="text-indigo-600 font-semibold">
                <Bell className="h-4 w-4 mr-2" />
                Alerts
              </Button>
            </Link>
            <span className="text-gray-600">{user?.name}</span>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Budget Price Alerts</h2>

        {/* Create Alert Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Create Price Drop Alert</CardTitle>
            <CardDescription>
              Set a budget price and get notified when the product price drops to your target price
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateAlert} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Product Name
                  </label>
                  <Input
                    type="text"
                    placeholder="e.g., iPhone 15"
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    list="products"
                  />
                  <datalist id="products">
                    {supportedProducts?.map((product) => (
                      <option key={product} value={product} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Platform
                  </label>
                  <select
                    value={platform}
                    onChange={(e) => setPlatform(e.target.value as "amazon" | "flipkart")}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="amazon">Amazon</option>
                    <option value="flipkart">Flipkart</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Price (₹)
                  </label>
                  <Input
                    type="number"
                    placeholder="e.g., 79999"
                    value={currentPrice}
                    onChange={(e) => setCurrentPrice(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Target Budget Price (₹)
                  </label>
                  <Input
                    type="number"
                    placeholder="e.g., 69999"
                    value={budgetPrice}
                    onChange={(e) => setBudgetPrice(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Creating Alert...
                  </>
                ) : (
                  <>
                    <Bell className="h-4 w-4 mr-2" />
                    Create Price Alert
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Active Alerts */}
        <div>
          <h3 className="text-xl font-bold text-gray-900 mb-4">Your Price Alerts</h3>
          {isLoading ? (
            <div className="text-center py-8">
              <Loader2 className="h-8 w-8 animate-spin mx-auto text-indigo-600" />
              <p className="text-gray-600 mt-2">Loading alerts...</p>
            </div>
          ) : alerts && alerts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {alerts.map((alert) => {
                const priceDropPercentage = getPriceDropPercentage(alert.currentPrice, alert.budgetPrice);
                const isPriceReached = alert.currentPrice <= alert.budgetPrice;

                return (
                  <Card
                    key={alert.id}
                    className={`${
                      isPriceReached
                        ? "border-2 border-green-500 bg-green-50"
                        : "border border-gray-200"
                    }`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{alert.productName}</CardTitle>
                          <CardDescription>
                            {alert.platform.charAt(0).toUpperCase() + alert.platform.slice(1)}
                          </CardDescription>
                        </div>
                        {isPriceReached && (
                          <CheckCircle className="h-5 w-5 text-green-600 ml-2" />
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="bg-white p-3 rounded border border-gray-200">
                          <p className="text-xs text-gray-600 mb-1">Current Price</p>
                          <p className="text-2xl font-bold text-indigo-600">
                            ₹{alert.currentPrice.toFixed(0)}
                          </p>
                        </div>

                        <div className="bg-white p-3 rounded border border-gray-200">
                          <p className="text-xs text-gray-600 mb-1">Target Budget Price</p>
                          <p className="text-2xl font-bold text-green-600">
                            ₹{alert.budgetPrice.toFixed(0)}
                          </p>
                        </div>

                        <div className="bg-gray-100 p-3 rounded">
                          <p className="text-xs text-gray-600 mb-1">Price Drop Needed</p>
                          <p className="text-lg font-semibold text-gray-900">
                            ₹{(alert.currentPrice - alert.budgetPrice).toFixed(0)} ({priceDropPercentage}%)
                          </p>
                        </div>

                        {isPriceReached && (
                          <div className="bg-green-100 border border-green-300 rounded p-3">
                            <p className="text-sm font-semibold text-green-800">
                              ✓ Price target reached! Time to buy!
                            </p>
                          </div>
                        )}

                        <Button
                          variant="destructive"
                          size="sm"
                          className="w-full"
                          onClick={() => handleDeleteAlert(alert.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete Alert
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">No price alerts yet. Create one to get started!</p>
                <p className="text-sm text-gray-500">
                  Set a target price and we'll notify you when the product price drops to your budget.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
