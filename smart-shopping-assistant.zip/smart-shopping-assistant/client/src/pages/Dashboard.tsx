import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { APP_LOGO, APP_TITLE } from "@/const";
import { Link } from "wouter";
import { ShoppingCart, TrendingDown, BarChart3 } from "lucide-react";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();

  const { data: savingsData, isLoading: savingsLoading } = trpc.dashboard.getSavings.useQuery();
  const { data: recentComparisons, isLoading: comparisonsLoading } = trpc.dashboard.getRecentComparisons.useQuery();

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            {APP_LOGO && <img src={APP_LOGO} alt="Logo" className="h-8 w-8" />}
            <h1 className="text-2xl font-bold text-indigo-600">{APP_TITLE}</h1>
          </div>
          <div className="flex gap-4 items-center">
            <Link href="/comparison">
              <Button variant="ghost">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Compare
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost">
                <BarChart3 className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <Link href="/prediction">
              <Button variant="ghost">
                <TrendingDown className="h-4 w-4 mr-2" />
                Predict
              </Button>
            </Link>
            <span className="text-gray-600">{user?.name}</span>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Your Savings Dashboard</h2>

        {/* Savings Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Total Savings Card */}
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="bg-green-100 p-2 rounded-lg">
                  <BarChart3 className="h-6 w-6 text-green-600" />
                </div>
                Total Savings
              </CardTitle>
            </CardHeader>
            <CardContent>
              {savingsLoading ? (
                <div className="text-2xl font-bold text-gray-600">Loading...</div>
              ) : (
                <>
                  <div className="text-4xl font-bold text-green-600 mb-2">
                    ₹{(savingsData?.totalSavings || 0).toFixed(2)}
                  </div>
                  <p className="text-gray-600">
                    You've saved this much by using our platform
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          {/* Comparisons Count Card */}
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="bg-blue-100 p-2 rounded-lg">
                  <ShoppingCart className="h-6 w-6 text-blue-600" />
                </div>
                Comparisons Made
              </CardTitle>
            </CardHeader>
            <CardContent>
              {savingsLoading ? (
                <div className="text-2xl font-bold text-gray-600">Loading...</div>
              ) : (
                <>
                  <div className="text-4xl font-bold text-blue-600 mb-2">
                    {savingsData?.comparisonsCount || 0}
                  </div>
                  <p className="text-gray-600">
                    Total price comparisons you've made
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Average Savings */}
        <Card className="mb-8 bg-gradient-to-br from-purple-50 to-pink-50">
          <CardHeader>
            <CardTitle>Average Savings Per Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            {savingsLoading ? (
              <div className="text-2xl font-bold text-gray-600">Loading...</div>
            ) : (
              <>
                <div className="text-4xl font-bold text-purple-600 mb-2">
                  ₹{(savingsData && savingsData.comparisonsCount > 0
                    ? (savingsData.totalSavings / savingsData.comparisonsCount).toFixed(2)
                    : 0)}
                </div>
                <p className="text-gray-600">
                  Average amount saved on each comparison
                </p>
              </>
            )}
          </CardContent>
        </Card>

        {/* Recent Comparisons */}
        <div>
          <h3 className="text-xl font-bold text-gray-900 mb-4">Recent Comparisons</h3>
          {comparisonsLoading ? (
            <div className="text-center py-8">Loading...</div>
          ) : recentComparisons && recentComparisons.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-gray-100">
                    <th className="px-4 py-3 text-left font-semibold">Product</th>
                    <th className="px-4 py-3 text-left font-semibold">Amazon</th>
                    <th className="px-4 py-3 text-left font-semibold">Flipkart</th>
                    <th className="px-4 py-3 text-left font-semibold">Cheaper</th>
                    <th className="px-4 py-3 text-left font-semibold">You Save</th>
                  </tr>
                </thead>
                <tbody>
                  {recentComparisons.map((comparison) => (
                    <tr key={comparison.id} className="border-b hover:bg-gray-50">
                      <td className="px-4 py-3">{comparison.productName}</td>
                      <td className="px-4 py-3">₹{(comparison.amazonPrice || 0).toFixed(2)}</td>
                      <td className="px-4 py-3">₹{(comparison.flipkartPrice || 0).toFixed(2)}</td>
                      <td className="px-4 py-3">
                        <span className="inline-block px-3 py-1 rounded-full text-sm font-semibold bg-green-100 text-green-800">
                          {comparison.cheaperPlatform?.toUpperCase() || "N/A"}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-semibold text-green-600">
                        ₹{(comparison.savingsAmount || 0).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <p className="text-gray-600 mb-4">No comparisons yet</p>
                <Link href="/comparison">
                  <Button className="bg-indigo-600 hover:bg-indigo-700">
                    Start Comparing
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
