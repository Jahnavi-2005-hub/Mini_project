import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { useLocation } from "wouter";
import { APP_LOGO, APP_TITLE } from "@/const";
import { Link } from "wouter";
import { ShoppingCart, TrendingDown, BarChart3, Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function Prediction() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [productName, setProductName] = useState("");
  const [platform, setPlatform] = useState<"amazon" | "flipkart">("amazon");
  const [daysAhead, setDaysAhead] = useState("7");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPrediction, setGeneratedPrediction] = useState<any>(null);

  const { data: predictions, isLoading, refetch } = trpc.prediction.list.useQuery();
  const { data: supportedProducts } = trpc.products.getSupportedProducts.useQuery();
  
  const generateMutation = trpc.prediction.generate.useQuery(
    { 
      productName: productName,
      platform: platform,
      daysAhead: parseInt(daysAhead),
    },
    { enabled: false }
  );

  const createMutation = trpc.prediction.create.useMutation({
    onSuccess: () => {
      toast.success("Prediction saved successfully!");
      setProductName("");
      setGeneratedPrediction(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to save prediction");
    },
  });

  const handleGeneratePrediction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productName.trim()) {
      toast.error("Please enter a product name");
      return;
    }

    setIsGenerating(true);
    try {
      const result = await generateMutation.refetch();
      if (result.data?.prediction) {
        setGeneratedPrediction(result.data.prediction);
      } else if (result.data?.error) {
        toast.error(result.data.error);
      }
    } catch (error) {
      toast.error("Failed to generate prediction");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSavePrediction = () => {
    if (!generatedPrediction) return;

    const predictedDate = new Date();
    predictedDate.setDate(predictedDate.getDate() + generatedPrediction.daysAhead);

    createMutation.mutate({
      productName: generatedPrediction.productName,
      platform: generatedPrediction.platform,
      currentPrice: generatedPrediction.currentPrice,
      predictedPrice: generatedPrediction.predictedPrice,
      predictedDate: predictedDate,
      trend: generatedPrediction.trend,
      confidence: generatedPrediction.confidence,
    });
  };

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case "up":
        return "text-red-600";
      case "down":
        return "text-green-600";
      case "stable":
        return "text-blue-600";
      default:
        return "text-gray-600";
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return "↑";
      case "down":
        return "↓";
      case "stable":
        return "→";
      default:
        return "•";
    }
  };

  const getTrendDescription = (trend: string) => {
    switch (trend) {
      case "up":
        return "Price is expected to increase";
      case "down":
        return "Price is expected to decrease";
      case "stable":
        return "Price is expected to remain stable";
      default:
        return "Unknown trend";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            {APP_LOGO && <img src={APP_LOGO} alt="Logo" className="h-8 w-8" />}
            <h1 className="text-2xl font-bold text-indigo-600">{APP_TITLE}</h1>
          </div>
          <div className="flex gap-4 items-center">
            <Link href="/comparison">
              <Button variant="ghost">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Compare
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost">
                <BarChart3 className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <Link href="/prediction">
              <Button variant="ghost">
                <TrendingDown className="h-4 w-4 mr-2" />
                Predict
              </Button>
            </Link>
            <span className="text-gray-600">{user?.name}</span>
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Price Prediction</h2>

        {/* Prediction Generator */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Generate AI Price Prediction</CardTitle>
            <CardDescription>
              Uses trend-based algorithm to predict future prices based on historical data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleGeneratePrediction} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Product Name *
                  </label>
                  <Input
                    type="text"
                    placeholder="e.g., iPhone 15, Samsung Galaxy S24"
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    list="products"
                    required
                  />
                  <datalist id="products">
                    {supportedProducts?.map((product) => (
                      <option key={product} value={product} />
                    ))}
                  </datalist>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Platform *
                  </label>
                  <select
                    value={platform}
                    onChange={(e) => setPlatform(e.target.value as "amazon" | "flipkart")}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="amazon">Amazon</option>
                    <option value="flipkart">Flipkart</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Predict Price For (Days) *
                </label>
                <Input
                  type="number"
                  min="1"
                  max="90"
                  value={daysAhead}
                  onChange={(e) => setDaysAhead(e.target.value)}
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  How many days in the future to predict (1-90 days)
                </p>
              </div>

              <Button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700"
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Generating Prediction...
                  </>
                ) : (
                  "Generate Prediction"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Prediction Result */}
        {generatedPrediction && (
          <Card className="mb-8 border-2 border-purple-200 bg-purple-50">
            <CardHeader>
              <CardTitle>{generatedPrediction.productName}</CardTitle>
              <CardDescription>
                {generatedPrediction.platform.toUpperCase()} • Prediction for {generatedPrediction.daysAhead} days
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Price Comparison */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border rounded-lg p-4 bg-white">
                    <p className="text-sm text-gray-600 mb-2">Current Price</p>
                    <div className="text-3xl font-bold text-indigo-600">
                      ₹{generatedPrediction.currentPrice.toFixed(0)}
                    </div>
                  </div>
                  <div className="border rounded-lg p-4 bg-white">
                    <p className="text-sm text-gray-600 mb-2">Predicted Price</p>
                    <div className="text-3xl font-bold text-purple-600">
                      ₹{generatedPrediction.predictedPrice.toFixed(0)}
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      {generatedPrediction.predictedPrice > generatedPrediction.currentPrice
                        ? `+₹${(generatedPrediction.predictedPrice - generatedPrediction.currentPrice).toFixed(0)}`
                        : `-₹${(generatedPrediction.currentPrice - generatedPrediction.predictedPrice).toFixed(0)}`}
                    </p>
                  </div>
                </div>

                {/* Trend */}
                <div className="bg-white border rounded-lg p-4">
                  <p className="text-sm text-gray-600 mb-3">Price Trend</p>
                  <div className="flex items-center gap-3">
                    <div className={`text-4xl font-bold ${getTrendColor(generatedPrediction.trend)}`}>
                      {getTrendIcon(generatedPrediction.trend)}
                    </div>
                    <div>
                      <p className="text-lg font-semibold text-gray-900">
                        {generatedPrediction.trend.toUpperCase()}
                      </p>
                      <p className="text-sm text-gray-600">
                        {getTrendDescription(generatedPrediction.trend)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Confidence */}
                <div className="bg-white border rounded-lg p-4">
                  <p className="text-sm text-gray-600 mb-3">Prediction Confidence</p>
                  <div className="flex items-center gap-3">
                    <div className="flex-1">
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div
                          className="bg-indigo-600 h-3 rounded-full transition-all"
                          style={{ width: `${generatedPrediction.confidence}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-2xl font-bold text-indigo-600">
                      {generatedPrediction.confidence}%
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    {generatedPrediction.confidence >= 70
                      ? "High confidence prediction"
                      : generatedPrediction.confidence >= 50
                        ? "Moderate confidence prediction"
                        : "Low confidence prediction"}
                  </p>
                </div>

                {/* Reasoning */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex gap-2">
                    <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-blue-900 mb-1">How we predicted this:</p>
                      <p className="text-sm text-blue-800">{generatedPrediction.reasoning}</p>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={handleSavePrediction}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? "Saving..." : "Save This Prediction"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Saved Predictions */}
        <div>
          <h3 className="text-xl font-bold text-gray-900 mb-4">Your Predictions</h3>
          {isLoading ? (
            <div className="text-center py-8">
              <Loader2 className="h-8 w-8 animate-spin mx-auto text-indigo-600" />
              <p className="text-gray-600 mt-2">Loading predictions...</p>
            </div>
          ) : predictions && predictions.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {predictions.map((prediction) => (
                <Card key={prediction.id}>
                  <CardHeader>
                    <CardTitle className="text-lg">{prediction.productName}</CardTitle>
                    <CardDescription>
                      {prediction.platform.toUpperCase()} • {new Date(prediction.predictedDate).toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Current:</span>
                        <span className="font-semibold">₹{prediction.currentPrice.toFixed(0)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Predicted:</span>
                        <span className="font-semibold">₹{prediction.predictedPrice.toFixed(0)}</span>
                      </div>
                      <div className="border-t pt-3">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-gray-600">Trend:</span>
                          <span className={`font-semibold text-lg ${getTrendColor(prediction.trend)}`}>
                            {getTrendIcon(prediction.trend)} {prediction.trend.toUpperCase()}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600">Confidence:</span>
                          <div className="flex items-center gap-2">
                            <div className="w-20 bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-indigo-600 h-2 rounded-full"
                                style={{ width: `${prediction.confidence}%` }}
                              />
                            </div>
                            <span className="font-semibold text-sm">{prediction.confidence}%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <p className="text-gray-600 mb-4">No predictions yet. Generate one to get started!</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
