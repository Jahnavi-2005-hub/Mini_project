import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { Link } from "wouter";
import { ShoppingCart, TrendingDown, BarChart3, Zap, Bell, Check, Smartphone, Zap as Lightning } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900">
      {/* Navigation */}
      <nav className="bg-white/10 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            {APP_LOGO && <img src={APP_LOGO} alt="Logo" className="h-10 w-10 rounded-lg" />}
            <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-cyan-400 bg-clip-text text-transparent">{APP_TITLE}</h1>
          </div>
          <div className="flex gap-4 items-center">
            {isAuthenticated ? (
              <>
                <span className="text-white/80 hidden sm:inline">Welcome, {user?.name || "User"}!</span>
                <Link href="/dashboard">
                  <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">Dashboard</Button>
                </Link>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">Login</Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <div className="inline-block mb-6 px-4 py-2 bg-indigo-500/20 border border-indigo-500/50 rounded-full">
            <p className="text-indigo-300 text-sm font-semibold">🚀 Smart Shopping Made Easy</p>
          </div>
          <h2 className="text-5xl sm:text-6xl font-bold text-white mb-6 leading-tight">
            Find the Best Deals<br />
            <span className="bg-gradient-to-r from-indigo-400 to-cyan-400 bg-clip-text text-transparent">
              Instantly
            </span>
          </h2>
          <p className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto">
            Compare prices across Amazon and Flipkart, track your savings, predict future prices, and never miss a deal again.
          </p>
          {!isAuthenticated && (
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-700 hover:to-cyan-700 text-white px-8 py-6 text-lg">
                Get Started Free
              </Button>
            </a>
          )}
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-20">
          {/* Comparison Card */}
          <Card className="bg-white/10 backdrop-blur border-white/20 hover:bg-white/20 transition-all duration-300 hover:shadow-2xl hover:shadow-indigo-500/20">
            <CardHeader>
              <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-indigo-500 to-indigo-600 flex items-center justify-center mb-4">
                <ShoppingCart className="h-6 w-6 text-white" />
              </div>
              <CardTitle className="text-white">Price Comparison</CardTitle>
              <CardDescription className="text-gray-300">Compare instantly</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-300 mb-4">
                Find the best deals by comparing prices between Amazon and Flipkart in seconds.
              </p>
              {isAuthenticated && (
                <Link href="/comparison">
                  <Button variant="outline" className="w-full bg-white/10 border-white/30 text-white hover:bg-white/20">
                    Compare Now
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>

          {/* Dashboard Card */}
          <Card className="bg-white/10 backdrop-blur border-white/20 hover:bg-white/20 transition-all duration-300 hover:shadow-2xl hover:shadow-green-500/20">
            <CardHeader>
              <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center mb-4">
                <BarChart3 className="h-6 w-6 text-white" />
              </div>
              <CardTitle className="text-white">Dashboard</CardTitle>
              <CardDescription className="text-gray-300">Track savings</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-300 mb-4">
                View your total savings and see how much money you've saved using our platform.
              </p>
              {isAuthenticated && (
                <Link href="/dashboard">
                  <Button variant="outline" className="w-full bg-white/10 border-white/30 text-white hover:bg-white/20">
                    View Dashboard
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>

          {/* Prediction Card */}
          <Card className="bg-white/10 backdrop-blur border-white/20 hover:bg-white/20 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/20">
            <CardHeader>
              <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center mb-4">
                <TrendingDown className="h-6 w-6 text-white" />
              </div>
              <CardTitle className="text-white">Price Prediction</CardTitle>
              <CardDescription className="text-gray-300">AI-powered forecasts</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-300 mb-4">
                Get AI-powered predictions for future product prices to buy at the right time.
              </p>
              {isAuthenticated && (
                <Link href="/prediction">
                  <Button variant="outline" className="w-full bg-white/10 border-white/30 text-white hover:bg-white/20">
                    View Predictions
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>

          {/* Budget Alerts Card */}
          <Card className="bg-white/10 backdrop-blur border-white/20 hover:bg-white/20 transition-all duration-300 hover:shadow-2xl hover:shadow-red-500/20">
            <CardHeader>
              <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-red-500 to-orange-600 flex items-center justify-center mb-4">
                <Bell className="h-6 w-6 text-white" />
              </div>
              <CardTitle className="text-white">Price Alerts</CardTitle>
              <CardDescription className="text-gray-300">Smart notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-300 mb-4">
                Set budget prices and get instant notifications when products drop to your target price.
              </p>
              {isAuthenticated && (
                <Link href="/budget-alerts">
                  <Button variant="outline" className="w-full bg-white/10 border-white/30 text-white hover:bg-white/20">
                    Set Alerts
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>

          {/* Features Card */}
          <Card className="bg-white/10 backdrop-blur border-white/20 hover:bg-white/20 transition-all duration-300 hover:shadow-2xl hover:shadow-yellow-500/20">
            <CardHeader>
              <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-yellow-500 to-amber-600 flex items-center justify-center mb-4">
                <Lightning className="h-6 w-6 text-white" />
              </div>
              <CardTitle className="text-white">Smart Features</CardTitle>
              <CardDescription className="text-gray-300">Powered by AI</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-300 mb-4">
                Real-time price tracking, savings analytics, and intelligent price forecasting.
              </p>
              {!isAuthenticated && (
                <a href={getLoginUrl()}>
                  <Button variant="outline" className="w-full bg-white/10 border-white/30 text-white hover:bg-white/20">
                    Learn More
                  </Button>
                </a>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Stats Section */}
        <div className="bg-gradient-to-r from-indigo-600/20 to-cyan-600/20 backdrop-blur border border-white/20 rounded-2xl p-12 mb-20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold bg-gradient-to-r from-indigo-400 to-cyan-400 bg-clip-text text-transparent">10,000+</div>
              <p className="text-gray-300 mt-2 text-sm">Active Users</p>
            </div>
            <div>
              <div className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">₹50L+</div>
              <p className="text-gray-300 mt-2 text-sm">Total Savings</p>
            </div>
            <div>
              <div className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">2M+</div>
              <p className="text-gray-300 mt-2 text-sm">Comparisons Made</p>
            </div>
            <div>
              <div className="text-4xl font-bold bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent">100K+</div>
              <p className="text-gray-300 mt-2 text-sm">Price Alerts Set</p>
            </div>
          </div>
        </div>

        {/* Benefits Section */}
        <div className="bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-12 mb-20">
          <h3 className="text-3xl font-bold text-white mb-8 text-center">Why Choose Us?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex gap-4">
              <div className="h-8 w-8 rounded-full bg-indigo-500/30 flex items-center justify-center flex-shrink-0 mt-1">
                <Check className="h-5 w-5 text-indigo-400" />
              </div>
              <div>
                <h4 className="text-white font-semibold mb-2">Real-Time Comparison</h4>
                <p className="text-gray-400 text-sm">Get instant price comparisons from multiple platforms with live updates.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="h-8 w-8 rounded-full bg-green-500/30 flex items-center justify-center flex-shrink-0 mt-1">
                <Check className="h-5 w-5 text-green-400" />
              </div>
              <div>
                <h4 className="text-white font-semibold mb-2">Smart Predictions</h4>
                <p className="text-gray-400 text-sm">AI-powered algorithms predict future prices to help you buy at the best time.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="h-8 w-8 rounded-full bg-purple-500/30 flex items-center justify-center flex-shrink-0 mt-1">
                <Check className="h-5 w-5 text-purple-400" />
              </div>
              <div>
                <h4 className="text-white font-semibold mb-2">Save More Money</h4>
                <p className="text-gray-400 text-sm">Track your savings and never miss a deal with smart price alerts.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-black/40 border-t border-white/10 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-400">&copy; 2024 Smart Online Shopping Assistant. All rights reserved.</p>
          <p className="text-gray-500 text-sm mt-2">Compare, Save, and Shop Smart</p>
        </div>
      </footer>
    </div>
  );
}
